#ifndef TASK1_H_INCLUDED
#define TASK1_H_INCLUDED


#include <iostream>
#include <string>
#include <windows.h>
#include <fstream>
#include <stdexcept>

// Player record
struct Player {
    std::string name; // stored as UTF-8
    int rank;         // lower number = higher ranking
};

// A simple min‑heap (priority queue) by rank
class MinHeap {
private:
    Player* data;
    int capacity, size;

    void siftUp(int idx) {
        while (idx > 0) {
            int parent = (idx - 1) / 2;
            if (data[idx].rank < data[parent].rank) {
                std::swap(data[idx], data[parent]);
                idx = parent;
            } else {
                break;
            }
        }
    }

    void siftDown(int idx) {
        while (true) {
            int left  = 2*idx + 1;
            int right = 2*idx + 2;
            int smallest = idx;
            if (left  < size && data[left].rank  < data[smallest].rank) smallest = left;
            if (right < size && data[right].rank < data[smallest].rank) smallest = right;
            if (smallest != idx) {
                std::swap(data[idx], data[smallest]);
                idx = smallest;
            } else {
                break;
            }
        }
    }

    // double capacity if full
    void ensureCapacity() {
        if (size < capacity) return;
        int newCap = capacity * 2;
        Player* newData = new Player[newCap];
        for (int i = 0; i < size; ++i) newData[i] = data[i];
        delete[] data;
        data = newData;
        capacity = newCap;
    }

public:
    MinHeap(int cap = 16)
      : capacity(cap), size(0)
    {
        data = new Player[capacity];
    }

    ~MinHeap() {
        delete[] data;
    }

    /// Insert a player (O(log n))
    void push(const Player& p) {
        ensureCapacity();
        data[size++] = p;
        siftUp(size - 1);
    }

    /// Remove and return the highest‑priority player (lowest rank)
    Player pop() {
        if (size == 0) throw std::out_of_range("Heap is empty");
        Player top = data[0];
        data[0] = data[--size];
        siftDown(0);
        return top;
    }

    bool empty() const { return size == 0; }
    int  getSize() const { return size; }
};

// Simple circular queue to buffer players for the next round
class CircularQueue {
private:
    Player* buffer;
    int capacity, front, rear, count;

public:
    CircularQueue(int cap = 16)
      : capacity(cap), front(0), rear(0), count(0)
    {
        buffer = new Player[capacity];
    }

    ~CircularQueue() {
        delete[] buffer;
    }

    /// Add to back
    void enqueue(const Player& p) {
        if (count == capacity) {
            // grow
            int newCap = capacity * 2;
            Player* newBuf = new Player[newCap];
            for (int i = 0; i < count; ++i) {
                newBuf[i] = buffer[(front + i) % capacity];
            }
            delete[] buffer;
            buffer = newBuf;
            capacity = newCap;
            front = 0;
            rear = count;
        }
        buffer[rear] = p;
        rear = (rear + 1) % capacity;
        ++count;
    }

    /// Remove from front
    Player dequeue() {
        if (count == 0) throw std::out_of_range("Queue is empty");
        Player p = buffer[front];
        front = (front + 1) % capacity;
        --count;
        return p;
    }

    bool empty() const { return count == 0; }
    int  size()  const { return count; }
};  // <-- **Make sure this semicolon is here**


// Play one round: pop pairs from heap, output match, log to CSV, enqueue winners
void runRound(MinHeap& heap, int round, std::ofstream& logFile) {
    CircularQueue nextQueue;

    // CSV header (only once, but repeating harmless)
    logFile << "Round,Player1,Rank1,Player2,Rank2,Winner\n";

    std::cout << "\n--- Round " << round << " Matches ---\n";

    // Pair off until fewer than 2 remain
    while (heap.getSize() >= 2) {
        Player p1 = heap.pop();
        Player p2 = heap.pop();
        Player winner = (p1.rank < p2.rank ? p1 : p2);

        // Console output
        std::cout
            << p1.name << " (Rank " << p1.rank << ") vs "
            << p2.name << " (Rank " << p2.rank << ") -> "
            << winner.name << " wins\n";

        // CSV log
        logFile
            << round << ","
            << p1.name << "," << p1.rank << ","
            << p2.name << "," << p2.rank << ","
            << winner.name << "\n";

        nextQueue.enqueue(winner);
    }

    // If one left over, auto‑advance
    if (!heap.empty()) {
        Player lone = heap.pop();
        std::cout << lone.name << " advances automatically\n";
        logFile
            << round << ","
            << lone.name << "," << lone.rank
            << ",,,," << lone.name << "\n";
        nextQueue.enqueue(lone);
    }

    // Build next round's heap from queue
    MinHeap nextHeap;
    while (!nextQueue.empty()) {
        nextHeap.push(nextQueue.dequeue());
    }

    // Recurse or finish
    if (nextHeap.getSize() > 1) {
        runRound(nextHeap, round + 1, logFile);
    } else if (nextHeap.getSize() == 1) {
        Player champ = nextHeap.pop();
        std::cout << "\n=== Champion: " << champ.name
                  << " (Rank " << champ.rank << ") ===\n";
        logFile << "Champion," << champ.name << "," << champ.rank << "\n";
    }
}

int runTask1() {
    // Enable UTF-8 in Windows console (optional if only ASCII)
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    try {
        int n;
        std::cout << "Enter number of players: ";
        if (!(std::cin >> n) || n <= 0) {
            throw std::invalid_argument("Must enter an integer > 0");
        }

        MinHeap heap;
        for (int i = 0; i < n; ++i) {
            Player p;
            std::cout << "Player " << (i + 1) << " Name and Rank: ";
            if (!(std::cin >> p.name >> p.rank) || p.rank < 1) {
                throw std::invalid_argument("Rank must be a positive integer");
            }
            heap.push(p);
        }

        std::ofstream logFile("results.csv");
        if (!logFile.is_open()) {
            throw std::runtime_error("Cannot create results.csv");
        }

        runRound(heap, 1, logFile);
    }
    catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << "\nProgram terminating.\n";
        return 1;
    }

    return 0;
}


#endif // TASK1_H_INCLUDED
