#include <iostream>
#include "task1.h"
#include "task2.h"
#include "task3.h"
#include "task4.h"
using namespace std;

int main() {
    int mainChoice;
    do {
        cout << "\n=============================\n";
        cout << "Esports Championship Menu\n";
        cout << "=============================\n";
        cout << "1. Match Scheduling & Player Progression\n";
        cout << "2. Tournament Registration & Player Queueing\n";
        cout << "3. Live Stream & Spectator Queue Management\n";
        cout << "4. Game Result Logging & Performance History\n";
        cout << "5. Quit\n";
        cout << "Enter your choice: ";
        cin >> mainChoice;
        cin.ignore();

        if (mainChoice == 1) {
            runTask1();
        } else if (mainChoice == 2) {
            runtask2();
        } else if (mainChoice == 3) {
            liveStreamSpectatorManagementMenu();
        } else if (mainChoice == 4) {
            runTask4();
        } else if (mainChoice == 5) {
            cout << "Exiting program. Goodbye!\n";
        } else {
            cout << "Invalid choice. Please try again.\n";
        }

    } while (mainChoice != 5);

    return 0;
}
