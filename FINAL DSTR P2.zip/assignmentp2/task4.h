#ifndef TASK4_H
#define TASK4_H

#include <iostream>
#include <string>
#include <cstring>

using namespace std;

const int MAX_MATCHES = 50;
const int MAX_PLAYERS = 20;

// Structure to store individual match result
struct Match {
    string player1;
    string player2;
    int score1;
    int score2;
    string winner;
};

// Circular queue to store recent matches
struct MatchQueue {
    Match matches[MAX_MATCHES];
    int front = 0;
    int rear = -1;
    int count = 0;

    bool isFull() { return count == MAX_MATCHES; }
    bool isEmpty() { return count == 0; }

    void enqueue(const Match& m) {
        if (isFull()) {
            front = (front + 1) % MAX_MATCHES; // overwrite oldest
            rear = (rear + 1) % MAX_MATCHES;
            matches[rear] = m;
        } else {
            rear = (rear + 1) % MAX_MATCHES;
            matches[rear] = m;
            count++;
        }
    }

    void displayRecentMatches() {
        cout << "\nRecent Match Results:" << endl;
        for (int i = 0; i < count; ++i) {
            int idx = (front + i) % MAX_MATCHES;
            cout << matches[idx].player1 << " vs " << matches[idx].player2
                 << " => " << matches[idx].score1 << "-" << matches[idx].score2
                 << " | Winner: " << matches[idx].winner << endl;
        }
    }
};

// Stack to track player win history
struct PlayerRecord {
    string player;
    int wins;
    int losses;
    int totalMatches;
};

struct PlayerHistory {
    PlayerRecord records[MAX_PLAYERS];
    int top = -1;

    int findPlayerIndex(const string& name) {   // Searches for a player by name and returns their index in the array
        for (int i = 0; i <= top; ++i) {
            if (records[i].player == name) return i;
        }
        return -1;
    }

    void updatePlayer(const string& name, bool won) {
        int idx = findPlayerIndex(name);
        if (idx == -1) {                        // New player
            if (top + 1 >= MAX_PLAYERS) return;     // Prevent overflow
            top++;
            records[top].player = name;
            records[top].wins = won ? 1 : 0;    // Updates the performance stats of a player
            records[top].losses = won ? 0 : 1;
            records[top].totalMatches = 1;
        } else {                                // Existing player
            if (won) records[idx].wins++;       // Updates the performance stats of a player
            else records[idx].losses++;
            records[idx].totalMatches++;
        }
    }

    void displayStats() {
        cout << "\nPlayer Performance History:" << endl;
        for (int i = 0; i <= top; ++i) {
            cout << records[i].player << " | Wins: " << records[i].wins
                 << ", Losses: " << records[i].losses
                 << ", Total: " << records[i].totalMatches << endl;
        }
    }
};

void runTask4(){
    MatchQueue matchLog;
    PlayerHistory history;
    int choice;
    do {
        cout << "\n--- E-Sports Match Logging System ---\n";
        cout << "1. Log new match result\n";
        cout << "2. Display all recorded results\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            Match m;
            cout << "Enter Player 1 name: "; getline(cin, m.player1);
            cout << "Enter Player 2 name: "; getline(cin, m.player2);
            cout << "Enter Player 1 score: "; cin >> m.score1;
            cout << "Enter Player 2 score: "; cin >> m.score2;
            cin.ignore();

            if (m.score1 > m.score2) m.winner = m.player1;
            else if (m.score2 > m.score1) m.winner = m.player2;
            else m.winner = "Draw";

            matchLog.enqueue(m);

            if (m.winner != "Draw") {
                history.updatePlayer(m.player1, m.winner == m.player1);
                history.updatePlayer(m.player2, m.winner == m.player2);
            }

        } else if (choice == 2) {
            matchLog.displayRecentMatches();
            history.displayStats();
        } else if (choice != 3) {
            cout << "Invalid choice. Please enter 1, 2, or 3.";
        }

    } while (choice != 3);
}

#endif // TASK4_H
