#ifndef TASK2_H_INCLUDED
#define TASK2_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <limits>
#include <cctype>
#include <sstream>

// Player Structure (renamed to PlayerT2)
struct PlayerT2 {
    std::string playerID;
    std::string name;
    std::string playerType;
    int registrationTime;

    // Default constructor
    PlayerT2() : playerID("0000"), name("None"), playerType("Regular"), registrationTime(-1) {}

    // Parameterized constructor
    PlayerT2(std::string id, std::string n, std::string type, int regTime)
        : playerID(id), name(n), playerType(type), registrationTime(regTime) {}

    // Function to save player information to a CSV file
    void saveToFile(std::ofstream& outFile) {
        outFile << playerID << "," << name << "," << playerType << "," << registrationTime << "\n";
        outFile.flush();
    }

    // Function to load player information from a CSV file
    static PlayerT2 loadFromFile(const std::string& playerData) {
        std::istringstream ss(playerData);
        std::string id, name, type, regTimeStr;
        int registrationTime;

        std::getline(ss, id, ',');
        std::getline(ss, name, ',');
        std::getline(ss, type, ',');
        std::getline(ss, regTimeStr, ',');

        registrationTime = std::stoi(regTimeStr);
        return PlayerT2(id, name, type, registrationTime);
    }
};

// Combined Queue Class for managing both VIP and Normal players
class PlayerQueue {
private:
    std::vector<PlayerT2> queue;

public:
    // Add player to the queue (Enqueue) with priority for EarlyBird and Wildcard
    void enqueue(const PlayerT2& player) {
        if (player.playerType == "EarlyBird" || player.playerType == "Wildcard") {
            queue.insert(queue.begin(), player);
        } else {
            queue.push_back(player);
        }
    }

    // Remove player from the queue (Dequeue)
    PlayerT2 dequeue() {
        if (queue.empty()) {
            std::cout << "Queue is empty!" << std::endl;
            return PlayerT2("0000", "None", "Regular", -1);
        }
        PlayerT2 player = queue.front();
        queue.erase(queue.begin());
        return player;
    }

    // Check if the queue is empty
    bool isEmpty() {
        return queue.empty();
    }

    // Get the size of the queue
    int size() {
        return queue.size();
    }

    // Find player by playerID
    PlayerT2 findPlayerByID(const std::string& id) {
        for (const auto& p : queue) {
            if (p.playerID == id) {
                return p;
            }
        }
        return PlayerT2("0000", "None", "Regular", -1);
    }

    // Load all players from a CSV into the queue
    void loadPlayersFromFile(std::ifstream& inFile) {
        std::string line;
        std::getline(inFile, line);

        while (std::getline(inFile, line)) {
            PlayerT2 p = PlayerT2::loadFromFile(line);
            enqueue(p);
        }
    }

    // Remove player by playerID from the queue
    void removePlayerByID(const std::string& playerID) {
        auto it = std::remove_if(queue.begin(), queue.end(), [&](const PlayerT2& p) { return p.playerID == playerID; });
        if (it != queue.end()) {
            queue.erase(it, queue.end());
        }
    }

    // Display the queue in a table format, highlighting the matching playerID
    void displayQueueWithHighlight(const std::string& playerID) {
        std::cout << std::left
                  << std::setw(10) << "PlayerID"
                  << std::setw(20) << "Name"
                  << std::setw(15) << "Type"
                  << std::setw(15) << "RegTime" << std::endl;

        // Print a line separator
        std::cout << std::string(60, '-') << std::endl;

        // Print each player in the queue
        for (const auto& player : queue) {
            if (player.playerID == playerID) {
                std::cout << std::left
                          << std::setw(10) << "[*] " << std::setw(20) << player.name
                          << std::setw(15) << player.playerType
                          << std::setw(15) << player.registrationTime << std::endl;
            } else {
                std::cout << std::left
                          << std::setw(10) << player.playerID << std::setw(20) << player.name
                          << std::setw(15) << player.playerType
                          << std::setw(15) << player.registrationTime << std::endl;
            }
        }
    }
};

// Function to handle player registration and save it to a file
std::string generatePlayerID(const std::string& filename) {
    std::ifstream inFile(filename);
    std::string line;
    int playerCount = 0;

    // Skip the header line
    std::getline(inFile, line);

    // Count the number of players in the file
    while (std::getline(inFile, line)) {
        playerCount++;
    }

    // Generate ID with leading zeros
    std::ostringstream ss;
    ss << std::setw(4) << std::setfill('0') << playerCount + 1;
    return ss.str();
}

bool isEarlyBirdDateValid(const std::string& date) {
    int year, month, day;
    char dash;
    std::istringstream dateStream(date);

    dateStream >> year >> dash >> month >> dash >> day;

    // Early bird date is valid if it's before May (month < 5)
    return month < 5;
}

bool isWildcardCodeValid(const std::string& code) {
    return code == "G00DG4M3";
}

// Function prototypes
void processCheckIns(PlayerQueue& playerQueue);
void withdrawPlayer(PlayerQueue& playerQueue, std::ofstream& outFile, const std::string& filename);

void registerPlayer(PlayerQueue& playerQueue, std::ofstream& outFile, const std::string& filename) {
    std::string name, playerType;
    int registrationTime;
    std::string date, secretCode;
    char typeChoice;

    // Auto-generate player ID based on existing entries
    std::string playerID = generatePlayerID(filename);
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::cout << "Enter Player Name: ";
    std::getline(std::cin, name);

    // Validate typeChoice input
    while (true) {
        std::cout << "Are you an Early Bird (E) or Wildcard (W) or Regular (R)? ";
        std::cin >> typeChoice;
        typeChoice = std::toupper(typeChoice);
        if (typeChoice == 'E' || typeChoice == 'W' || typeChoice == 'R') {
            break;
        }
        std::cout << "Invalid input! Please enter E, W, or R.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    // Determine player type with validation
    if (typeChoice == 'E') {
        while (true) {
            std::cout << "Enter registration date (YYYY-MM-DD): ";
            std::cin >> date;
            if (isEarlyBirdDateValid(date)) {
                playerType = "EarlyBird";
                break;
            } else {
                playerType = "Regular";
                std::cout << "Invalid Early Bird date. It must be before May. You are assigned as Regular.\n";
                break;
            }
        }
    } else if (typeChoice == 'W') {
        while (true) {
            std::cout << "Enter secret code: ";
            std::cin >> secretCode;
            if (isWildcardCodeValid(secretCode)) {
                playerType = "Wildcard";
                break;
            }
            std::cout << "Invalid Wildcard code. Going back to the menu...\n";
            return;
        }
    } else {
        playerType = "Regular";
    }

    // Validate registrationTime input
    while (true) {
        std::cout << "Enter Registration Time (24-hour time): ";
        if (!(std::cin >> registrationTime) || registrationTime < 0) {
            std::cout << "Invalid registration time! Enter a non-negative integer.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }
        break;
    }

    PlayerT2 newPlayer(playerID, name, playerType, registrationTime);

    // Save player data to CSV file
    newPlayer.saveToFile(outFile);

    // Add the player to the queue
    playerQueue.enqueue(newPlayer);

    std::cout << "Player " << name << " registered successfully with PlayerID: " << playerID << "\n";
}

void processCheckIns(PlayerQueue& playerQueue) {
    std::string playerID;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::cout << "Enter Player ID to check-in: ";
    std::getline(std::cin, playerID);

    if (playerID.empty()) {
        std::cout << "Player ID cannot be empty.\n";
        return;
    }

    // Display the current queue and highlight the entered player
    std::cout << "\nCurrent Queue:\n";
    playerQueue.displayQueueWithHighlight(playerID);

    // Check for player in the combined queue
    PlayerT2 checkedInPlayer = playerQueue.findPlayerByID(playerID);
    if (checkedInPlayer.playerID != "0000") {
        std::cout << "Processing check-in for Player: " << checkedInPlayer.name << " (ID: " << checkedInPlayer.playerID << ")\n";
        playerQueue.dequeue();
    } else {
        std::cout << "Player not found in the queue.\n";
    }
}

void withdrawPlayer(PlayerQueue& playerQueue, std::ofstream& outFile, const std::string& filename) {
    std::string playerID;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    while (true) {
        std::cout << "Enter Player ID to withdraw (or type 'exit' to cancel): ";
        std::getline(std::cin, playerID);

        if (playerID == "exit") {
            std::cout << "Withdrawal canceled.\n";
            return;
        }

        if (playerID.empty()) {
            std::cout << "Player ID cannot be empty.\n";
            continue;
        }

        // Check if player exists in queue
        PlayerT2 player = playerQueue.findPlayerByID(playerID);
        if (player.playerID == "0000") {
            std::cout << "Player ID not found. Please enter a valid Player ID.\n";
            continue;
        }

        // Valid player found, display queue with highlight
        playerQueue.displayQueueWithHighlight(playerID);

        char confirm;
        while (true) {
            std::cout << "Are you sure you want to withdraw (y/n)? ";
            std::cin >> confirm;
            confirm = std::tolower(confirm);
            if (confirm == 'y' || confirm == 'n') {
                break;
            }
            std::cout << "Invalid input! Please enter 'y' or 'n'.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }

        if (confirm == 'y') {
            // Remove the player from the queue
            playerQueue.removePlayerByID(playerID);

            std::cout << "Player " << playerID << " has been withdrawn successfully from the queue.\n";
        } else {
            std::cout << "Withdrawal canceled.\n";
        }
        break;
    }
}

int runtask2() {
    PlayerQueue playerQueue;

    const std::string filename = "player_registration.csv";

    std::ofstream outFile(filename, std::ios::app);

    if (!outFile) {
        std::cout << "Error opening file!" << std::endl;
        return 1;
    }

    // Load previous players into the combined queue
    std::ifstream inFile(filename);
    playerQueue.loadPlayersFromFile(inFile);
    inFile.close();

    int choice;
    bool keepRunning = true;

    while (keepRunning) {
        std::cout << "\nEsports Championship Registration\n";
        std::cout << "1. Register Player\n";
        std::cout << "2. Process Check-in Queue\n";
        std::cout << "3. Withdraw Player\n";
        std::cout << "4. Exit\n";

        // Input validation loop
        while (true) {
            std::cout << "Enter your choice: ";
            if (!(std::cin >> choice)) {
                std::cout << "Invalid input! Please enter a number between 1 and 4.\n";
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }
            if (choice < 1 || choice > 4) {
                std::cout << "Invalid choice! Please enter a number between 1 and 4.\n";
                continue;
            }
            break;
        }

        switch (choice) {
            case 1:
                registerPlayer(playerQueue, outFile, filename);
                break;
            case 2:
                processCheckIns(playerQueue);
                break;
            case 3:
                withdrawPlayer(playerQueue, outFile, filename);
                break;
            case 4:
                keepRunning = false;
                break;
        }
    }

    outFile.close();
    return 0;
}

#endif // TASK2_H_INCLUDED
