#ifndef TASK3_H
#define TASK3_H

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cstdlib>   // For rand, srand
#include <ctime>     // For time()
using namespace std;

const int MAX_SLOTS_PER_ROOM = 6;
const int TOTAL_ROOMS = 10;
const int MAX_SPECTATORS = 100;  // Maximum number of spectators we can handle

struct Spectator {
    string name;
    int priority;
    string role;

    Spectator() {}
    Spectator(string n, string r) {
        name = n;
        role = r;
        if (r == "VIP") priority = 1;
        else if (r == "Streamer") priority = 2;
        else priority = 3;
    }
};

// Implement our own simple priority queue using arrays
class SimplePriorityQueue {
private:
    Spectator data[MAX_SPECTATORS];
    int size;

    // Helper function to maintain heap property
    void heapifyDown(int index) {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && data[left].priority < data[smallest].priority)
            smallest = left;
        if (right < size && data[right].priority < data[smallest].priority)
            smallest = right;

        if (smallest != index) {
            swap(data[index], data[smallest]);
            heapifyDown(smallest);
        }
    }

    void heapifyUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (data[index].priority >= data[parent].priority)
                break;
            swap(data[index], data[parent]);
            index = parent;
        }
    }

public:
    SimplePriorityQueue() : size(0) {}

    bool empty() const { return size == 0; }

    void push(const Spectator& s) {
        if (size >= MAX_SPECTATORS) return;
        data[size] = s;
        heapifyUp(size);
        size++;
    }

    Spectator top() const {
        return data[0];
    }

    void pop() {
        if (size == 0) return;
        data[0] = data[size - 1];
        size--;
        heapifyDown(0);
    }

    // Copy the queue (used for display purposes)
    SimplePriorityQueue copy() const {
        SimplePriorityQueue temp;
        for (int i = 0; i < size; i++) {
            temp.push(data[i]);
        }
        return temp;
    }
};

SimplePriorityQueue mainQueue;
SimplePriorityQueue overflowQueue;

// Utility function to shuffle an array of Spectators (Fisher-Yates shuffle)
void shuffleSpectators(Spectator arr[], int n) {
    for (int i = n - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        Spectator temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

// Load spectators from file into mainQueue
void loadSpectatorsFromFile() {
    mainQueue = SimplePriorityQueue();  // Clear previous queue
    ifstream infile("spectators.txt");
    if (!infile) {
        cerr << "Error opening spectators.txt.\n";
        return;
    }
    string line, name, role;
    while (getline(infile, line)) {
        stringstream ss(line);
        ss >> name >> role;
        mainQueue.push(Spectator(name, role));
    }
    infile.close();

    cout << "\nSpectators loaded into live queue successfully.\n";
}

// Display the current live queue or waiting list table
void showLiveQueueTable() {
    if (!overflowQueue.empty()) {
        // Show waiting room as the current live queue
        cout << "\n--- Spectators Table (Live Queue) ---\n";
        cout << "+-----+----------------------+------------+\n";
        cout << "| No. | Name                 | Role       |\n";
        cout << "+-----+----------------------+------------+\n";

        SimplePriorityQueue tempQueue = overflowQueue.copy();
        int idx = 1;
        while (!tempQueue.empty()) {
            Spectator s = tempQueue.top();
            tempQueue.pop();
            printf("| %-3d | %-20s | %-10s |\n", idx++, s.name.c_str(), s.role.c_str());
        }
        cout << "+-----+----------------------+------------+\n";
    } else if (!mainQueue.empty()) {
        // Show live queue from mainQueue
        cout << "\n--- Spectators Table (Live Queue) ---\n";
        cout << "+-----+----------------------+------------+\n";
        cout << "| No. | Name                 | Role       |\n";
        cout << "+-----+----------------------+------------+\n";

        SimplePriorityQueue tempQueue = mainQueue.copy();
        int idx = 1;
        while (!tempQueue.empty()) {
            Spectator s = tempQueue.top();
            tempQueue.pop();
            printf("| %-3d | %-20s | %-10s |\n", idx++, s.name.c_str(), s.role.c_str());
        }
        cout << "+-----+----------------------+------------+\n";
    } else {
        cout << "\nNo spectators to display.\n";
    }
}

// Assign spectators to rooms prioritizing VIP, Streamer, then Spectator
// Randomize room assignment within each priority group
void assignSlotsToRooms() {
    if (mainQueue.empty()) {
        cout << "Queue is empty. Load spectators first.\n";
        return;
    }

    // Separate by role using arrays
    Spectator vips[MAX_SPECTATORS];
    int vipCount = 0;
    Spectator streamers[MAX_SPECTATORS];
    int streamerCount = 0;
    Spectator spectators[MAX_SPECTATORS];
    int spectatorCount = 0;

    // Extract all from mainQueue into arrays by role
    while (!mainQueue.empty()) {
        Spectator s = mainQueue.top();
        mainQueue.pop();
        if (s.role == "VIP") vips[vipCount++] = s;
        else if (s.role == "Streamer") streamers[streamerCount++] = s;
        else spectators[spectatorCount++] = s;
    }

    // Seed random number generator
    srand((unsigned int)time(nullptr));

    // Shuffle each group so they are randomized within priority
    shuffleSpectators(vips, vipCount);
    shuffleSpectators(streamers, streamerCount);
    shuffleSpectators(spectators, spectatorCount);

    // Rooms: 2D array of Spectator structs
    Spectator rooms[TOTAL_ROOMS][MAX_SLOTS_PER_ROOM];
    int roomCounts[TOTAL_ROOMS] = {0};  // Slots used per room
    int totalAssigned = 0;

    // Function to assign group to rooms round-robin
    auto assignGroup = [&](Spectator group[], int count) {
        int roomIndex = 0;
        for (int i = 0; i < count; ++i) {
            if (totalAssigned >= TOTAL_ROOMS * MAX_SLOTS_PER_ROOM)
                break;
            // Assign to next available room slot
            while (roomCounts[roomIndex] >= MAX_SLOTS_PER_ROOM) {
                roomIndex = (roomIndex + 1) % TOTAL_ROOMS;
            }
            rooms[roomIndex][roomCounts[roomIndex]] = group[i];
            roomCounts[roomIndex]++;
            totalAssigned++;
            roomIndex = (roomIndex + 1) % TOTAL_ROOMS;
        }
    };

    assignGroup(vips, vipCount);
    assignGroup(streamers, streamerCount);
    assignGroup(spectators, spectatorCount);

    // Leftovers go to overflowQueue
    overflowQueue = SimplePriorityQueue();

    // Push leftovers for VIPs
    for (int i = totalAssigned; i < vipCount; i++) {
        overflowQueue.push(vips[i]);
    }
    // Push leftovers for Streamers
    for (int i = max(totalAssigned - vipCount, 0); i < streamerCount; i++) {
        overflowQueue.push(streamers[i]);
    }
    // Push leftovers for Spectators
    for (int i = max(totalAssigned - vipCount - streamerCount, 0); i < spectatorCount; i++) {
        overflowQueue.push(spectators[i]);
    }

    // Show room assignments ONLY
    cout << "\n=== Room Assignments ===\n";
    for (int r = 0; r < TOTAL_ROOMS; r++) {
        cout << "\nRoom " << (r + 1) << ":\n";
        cout << "+----------------------+------------+\n";
        cout << "| Name                 | Role       |\n";
        cout << "+----------------------+------------+\n";
        for (int s = 0; s < roomCounts[r]; s++) {
            printf("| %-20s | %-10s |\n", rooms[r][s].name.c_str(), rooms[r][s].role.c_str());
        }
        cout << "+----------------------+------------+\n";
    }
}

// View waiting room separately
void viewWaitingRoom() {
    if (overflowQueue.empty()) {
        cout << "\nNo spectators in the waiting room.\n";
        return;
    }

    cout << "\n--- Waiting Room ---\n";
    cout << "+----------------------+------------+\n";
    cout << "| Name                 | Role       |\n";
    cout << "+----------------------+------------+\n";

    SimplePriorityQueue temp = overflowQueue.copy();
    while (!temp.empty()) {
        Spectator s = temp.top();
        temp.pop();
        printf("| %-20s | %-10s |\n", s.name.c_str(), s.role.c_str());
    }
    cout << "+----------------------+------------+\n";
}

// Menu for live stream & spectator queue management
void liveStreamSpectatorManagementMenu() {
    int choice;
    do {
        cout << "\n--- Live Stream & Spectator Queue Management ---\n";
        cout << "+-----+-------------------------------+\n";
        cout << "| No. | Option                        |\n";
        cout << "+-----+-------------------------------+\n";
        cout << "| 1   | Load live queue               |\n";
        cout << "| 2   | Assign slots & generate report|\n";
        cout << "| 3   | View waiting room             |\n";
        cout << "| 4   | Exit                          |\n";
        cout << "+-----+-------------------------------+\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1:
                if (overflowQueue.empty()) {
                    loadSpectatorsFromFile();  // load from file only if waiting list empty
                }
                showLiveQueueTable();          // show waiting list if any, else mainQueue
                break;
            case 2:
                assignSlotsToRooms();
                break;
            case 3:
                viewWaitingRoom();
                break;
            case 4:
                cout << "Exiting to main menu...\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 4);
}

#endif
